public class FilePaths {
    static String jsonPath="/Users/ankitmane/Documents/SoftwareTesting/Project/src/main/resources/tcas";
    static String UniverseJson ="/Users/ankitmane/Documents/SoftwareTesting/Project/src/main/resources/tcas2";
    static String inputFile ="/Users/ankitmane/Documents/SoftwareTesting/Project/src/main/resources/tcas3/universe.txt";
}
